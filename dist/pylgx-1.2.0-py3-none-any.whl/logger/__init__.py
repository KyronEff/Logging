try:

    from logger import Logger

except ImportError:

    raise ImportError("The 'logger.py' module is required to initialize pylgx.")